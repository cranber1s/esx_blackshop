ESX = nil

if Config.Framework == "esx" then
    Citizen.CreateThread(function()
        while ESX == nil do
            TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
            Citizen.Wait(0)
        end
    end)
else
    ESX = exports["es_extended"]:getSharedObject()
end

RegisterServerEvent('kudre-blackmarket:buy')
AddEventHandler('kudre-blackmarket:buy', function(weaponModel, weaponPrice)
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer.getInventoryItem('money').count >= weaponPrice then
        exports.ox_inventory:RemoveItem(source, 'money', weaponPrice)
        exports.ox_inventory:AddItem(source, weaponModel, 1)
        TriggerClientEvent('kudre-blackmarket:notify', source, Config.Settings.locales.purshased .. weaponPrice)
    else
        TriggerClientEvent('kudre-blackmarket:notify', source, Config.Settings.locales.notenough)
    end
end)
